package com.example.todoapp.ui.main

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapp.R
import com.example.todoapp.data.local.TaskDatabase
import com.example.todoapp.data.model.Task
import com.example.todoapp.data.repository.TaskRepository
import com.example.todoapp.ui.detail.TaskDetailActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var repository: TaskRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerViewTasks)
        recyclerView.layoutManager = LinearLayoutManager(this)

        repository = TaskRepository(
            TaskDatabase.getInstance(this).taskDao()
        )

        findViewById<Button>(R.id.btnAddTask).setOnClickListener {
            startActivity(Intent(this, TaskDetailActivity::class.java))
        }

        loadTasks()
    }

    override fun onResume() {
        super.onResume()
        loadTasks()
    }

    private fun loadTasks() {
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) { repository.syncTasks() }
            } catch (_: Exception) {}

            val tasks = withContext(Dispatchers.IO) {
                repository.getTasks()
            }

            recyclerView.adapter = TaskAdapter(
                tasks,
                onClick = { toggleTask(it) },
                onLongClick = { deleteTask(it) }
            )
        }
    }

    private fun toggleTask(task: Task) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                repository.updateTask(task.copy(completed = !task.completed))
            }
            loadTasks()
        }
    }

    private fun deleteTask(task: Task) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                repository.deleteTask(task)
            }
            loadTasks()
        }
    }
}
