package com.example.todoapp.data.repository

import com.example.todoapp.data.local.TaskDao
import com.example.todoapp.data.model.Task
import com.example.todoapp.data.remote.RetrofitClient

class TaskRepository(private val dao: TaskDao) {

    suspend fun syncTasks() {
        val response = RetrofitClient.api.getTodos()
        dao.insertAll(response.todos)
    }

    suspend fun getTasks(): List<Task> = dao.getAll()

    suspend fun addTask(task: Task) = dao.insert(task)

    suspend fun updateTask(task: Task) = dao.update(task)

    suspend fun deleteTask(task: Task) = dao.delete(task)
}
