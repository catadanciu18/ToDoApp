package com.example.todoapp.data.remote

import com.example.todoapp.data.model.Task
import retrofit2.http.GET

interface ApiService {

    @GET("todos")
    suspend fun getTodos(): TodoResponse
}

data class TodoResponse(
    val todos: List<Task>
)
