package com.example.todoapp.ui.detail

import android.app.*
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.todoapp.R
import com.example.todoapp.data.local.TaskDatabase
import com.example.todoapp.data.model.Task
import com.example.todoapp.service.NotificationReceiver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*

class TaskDetailActivity : AppCompatActivity() {

    private var deadline: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_detail)

        val etTitle = findViewById<EditText>(R.id.etTitle)
        val btnPickDeadline = findViewById<Button>(R.id.btnPickDeadline)
        val tvDeadline = findViewById<TextView>(R.id.tvDeadline)
        val btnSave = findViewById<Button>(R.id.btnSave)

        btnPickDeadline.setOnClickListener {
            pickDeadline(tvDeadline)
        }

        btnSave.setOnClickListener {
            val title = etTitle.text.toString()
            if (title.isBlank()) return@setOnClickListener

            val task = Task(
                id = System.currentTimeMillis().toInt(),
                title = title,
                completed = false,
                deadline = deadline
            )

            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    TaskDatabase.getInstance(this@TaskDetailActivity)
                        .taskDao()
                        .insert(task)
                }

                if (deadline > System.currentTimeMillis()) {
                    scheduleNotification(task)
                }

                finish()
            }
        }
    }

    private fun pickDeadline(tv: TextView) {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, h, min ->
                cal.set(y, m, d, h, min)
                deadline = cal.timeInMillis
                tv.text = cal.time.toString()
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun scheduleNotification(task: Task) {
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, NotificationReceiver::class.java)
            .putExtra("title", task.title)

        val pendingIntent = PendingIntent.getBroadcast(
            this,
            task.id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        alarmManager.setExact(
            AlarmManager.RTC_WAKEUP,
            task.deadline,
            pendingIntent
        )
    }
}
